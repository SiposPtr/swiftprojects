import UIKit
// változó
var str = "Hello, playground"

print(str)

let name = "John"
print(name)

// változó,mely később változni fog
var age = 18
print(age)


// változók deklarálása
let defaultScore = 100
var playerOneScore = defaultScore
var playerTwoScore = defaultScore
// változók kiírása
print(playerOneScore)
print(playerTwoScore)
// változó értékének változtatása
playerOneScore = 200
print(playerOneScore)


let number: Double = 2
print(number)

var opponentScore = 3 * 8
// opponentScore has a value of 24
var myScore = 100 / 4
// myScore has a value of 25

let x = 51
let y = 4
let z = x / y // z has a value of 12

myScore += 3 // Adds 3 to myScore
myScore -= 5 // Subtracts 5 from myScore
myScore *= 2 // Multiples myScore by 2
myScore /= 2 // Divides myScore by 2


var t = 2
var r = 3
var e = 5

t + r * e // Equals 17
(t + r) * e // Equals 25

let temperature = 99

if temperature >= 65 && temperature <= 75 {
    print("The temperature is just right.")
} else if temperature < 65 {
    print("It is too cold.")
} else {
    print("It is too hot.")
}


// A basic switch statement takes a value with multiple options and allows you to run separate code based on each option, or case.
// You can also provide a default case to specify a block of code that will run in all the cases you haven't specifically defined.

let numberOfWheels = 1
switch numberOfWheels {
case 1:
    print("Unicycle")
case 2:
    print("Bicycle")
case 3:
    print("Tricycle")
case 4:
    print("Quadcycle")
default:
    print("That's a lot of wheels!")
}

